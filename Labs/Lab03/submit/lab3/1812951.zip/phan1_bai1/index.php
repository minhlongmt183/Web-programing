
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<h1> Phan 1 bai 1 </h1>

	<?php
		$x=10;
		$y=7;

		$sum = $x + $y;
		$sub = $x - $y;
		$mul = $x * $y;
		$div = $x / $y;
		$mod = $x % $y;


		echo "$x + $y = $sum <br>";
		echo "$x - $y = $sub <br>";
		echo "$x * $y = $mul <br>";
		echo "$x / $y = $div <br>";
		echo "$x % $y = $mod <br>";
	?>


</body>
</html>

